// import { MaxLengthValidationDirective } from './max-length-validation.directive';

// describe('MaxLengthValidationDirective', () => {
//   it('should create an instance', () => {
//     const directive = new MaxLengthValidationDirective();
//     expect(directive).toBeTruthy();
//   });
// });
