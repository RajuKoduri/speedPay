import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Agentcash',
  templateUrl: './Agentcash.component.html',
  styleUrls: ['./Agentcash.component.css']
})
export class AgentcashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
