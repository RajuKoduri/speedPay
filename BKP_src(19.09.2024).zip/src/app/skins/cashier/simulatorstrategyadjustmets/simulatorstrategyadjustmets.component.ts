import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simulatorstrategyadjustmets',
  templateUrl: './simulatorstrategyadjustmets.component.html',
  styleUrls: ['./simulatorstrategyadjustmets.component.css']
})
export class SimulatorstrategyadjustmetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
