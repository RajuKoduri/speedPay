import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Agentwithdrawl',
  templateUrl: './Agentwithdrawl.component.html',
  styleUrls: ['./Agentwithdrawl.component.css']
})
export class AgentwithdrawlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
