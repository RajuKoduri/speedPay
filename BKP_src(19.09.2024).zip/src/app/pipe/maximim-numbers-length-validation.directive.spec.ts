import { MaximimNumbersLengthValidationDirective } from './maximim-numbers-length-validation.directive';

describe('MaximimNumbersLengthValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new MaximimNumbersLengthValidationDirective();
    expect(directive).toBeTruthy();
  });
});
