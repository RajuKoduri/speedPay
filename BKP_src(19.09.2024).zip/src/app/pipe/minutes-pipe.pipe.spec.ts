import { MinutesPipePipe } from './minutes-pipe.pipe';

describe('MinutesPipePipe', () => {
  it('create an instance', () => {
    const pipe = new MinutesPipePipe();
    expect(pipe).toBeTruthy();
  });
});
