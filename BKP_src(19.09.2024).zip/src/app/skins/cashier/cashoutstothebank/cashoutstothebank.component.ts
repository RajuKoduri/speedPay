import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashoutstothebank',
  templateUrl: './cashoutstothebank.component.html',
  styleUrls: ['./cashoutstothebank.component.css']
})
export class CashoutstothebankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
