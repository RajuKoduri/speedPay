import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashfraudcontrol',
  templateUrl: './cashfraudcontrol.component.html',
  styleUrls: ['./cashfraudcontrol.component.css']
})
export class CashfraudcontrolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
