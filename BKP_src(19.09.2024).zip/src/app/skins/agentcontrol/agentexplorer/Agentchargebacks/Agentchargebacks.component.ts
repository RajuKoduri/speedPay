import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Agentchargebacks',
  templateUrl: './Agentchargebacks.component.html',
  styleUrls: ['./Agentchargebacks.component.css']
})
export class AgentchargebacksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
