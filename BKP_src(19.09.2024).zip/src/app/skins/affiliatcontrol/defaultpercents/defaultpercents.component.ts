import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultpercents',
  templateUrl: './defaultpercents.component.html',
  styleUrls: ['./defaultpercents.component.css']
})
export class DefaultpercentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
